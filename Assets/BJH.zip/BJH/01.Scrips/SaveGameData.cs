using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SaveGameData : MonoBehaviour
{
    public virtual void SaveNickName(string s)
    {

    }
     
    
}
